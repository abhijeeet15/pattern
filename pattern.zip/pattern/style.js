// 1 2 3 4 5
// 1 2 3 4 5
// 1 2 3 4 5
// 1 2 3 4 5

// for(let i=1; i<=4; i++){
//     for(let j=1; j<=5; j++){
//         document.writeln(j)    
//     }
//     document.writeln("<br>")
// }


// * * * * *
// * * * * *
// * * * * *
// * * * * *

//    for(let i=1; i<=4; i++){
//         for(let j=1; j<=5; j++){
//             document.writeln("*")    
//         }
//         document.writeln("<br>")
//     }


// 1 1 1 1 1
// 2 2 2 2 2
// 3 3 3 3 3
// 4 4 4 4 4

//    for(let i=1; i<=4; i++){
//         for(let j=1; j<=5; j++){
//             document.writeln(i)    
//         }
//         document.writeln("<br>")
//     }



// 1 - 3 - 5
// 1 - 3 - 5
// 1 - 3 - 5
// 1 - 3 - 5

// for(let i = 1; i <= 4; i++) {
//     for(let j = 1; j <= 5; j += 2) {
//         document.write(j);
//         if(j < 5) {
//             document.write(" - ");
//         }
//     }
//     document.write("<br>");
// }



// 1 0 1 0 1
// 1 0 1 0 1
// 1 0 1 0 1
// 1 0 1 0 1


// for (let i = 1; i <= 4; i++) {
//     for (let j = 1; j <= 5; j++) {
//         if (j % 2 === 1) {
//             document.write("1 ");
//         } else {
//             document.write("0 ");
//         }
//     }
//     document.write("<br>");
// }